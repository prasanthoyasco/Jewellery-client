import productRingImage1 from './product-ring-image1.webp'
import productRingImage2 from './product-ring-image2.webp'
import productRingImage3 from './product-ring-image3.webp'
import productRingImage4 from './product-ring-video1.mp4'

export const ProductPageImages = [
    productRingImage1,
    productRingImage2,
    productRingImage3,
    productRingImage4
]