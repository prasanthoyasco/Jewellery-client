import diamondRing from './GoldRings.png'
import silverRing from './Ringspng.png'
import goldRing from './GoldRings.png'
import billions from './Bullions.png'

export const salesItem = [
    {name :"Diamond",image : diamondRing,quote : "The most awaited moment!",price : "1,00,000"},
    {name :"Silver",image : silverRing,quote : "For everyday elegance!",price : "1,00,000"},
    {name :"Gold",image : goldRing,quote : "For the beauty and the bliss!",price : "1,00,000"},
    {name :"Billions",image : billions,quote : "For auspicious occasions!",price : "1,00,000"},
    {name :"Diamond",image : diamondRing,quote : "The most awaited moment!",price : "1,00,000"},
    {name :"Silver",image : silverRing,quote : "For everyday elegance!",price : "1,00,000"},
    {name :"Gold",image : goldRing,quote : "For the beauty and the bliss!",price : "1,00,000"},
    {name :"Billions",image : billions,quote : "For auspicious occasions!",price : "1,00,000"},
    {"name": "Diamond Metti",
  "karat": "24k",
  "image": "1745475870739-image.png",
  "weight": 5,
  "makingCostPercent": 2.5,
  "wastagePercent": 2.5,
  "price": 47250,
  "_id": "6809d91e6fcd210a17b353fd",
  "createdAt": "2025-04-24T06:24:30.894Z",
  "updatedAt": "2025-04-24T06:24:30.894Z",
  "__v": 0,
  "makingCost": 1125,
  "wastageCost": 1125}
]